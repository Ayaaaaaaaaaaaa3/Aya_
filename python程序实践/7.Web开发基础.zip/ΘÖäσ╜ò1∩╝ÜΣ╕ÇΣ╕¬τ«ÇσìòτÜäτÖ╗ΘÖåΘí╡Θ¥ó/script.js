document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    
    // Simple validation (you may replace with more robust validation)
    if (username === '' || password === '') {
        document.getElementById('error-message').textContent = 'Please enter both username and password.';
        return;
    }
    
    // Simulate login (replace with actual login logic)
    if (username === 'admin' && password === 'password') {
        // Redirect to dashboard or another page
        window.location.href = 'dashboard.html';
    } else {
        document.getElementById('error-message').textContent = 'Invalid username or password. Please try again.';
    }
});